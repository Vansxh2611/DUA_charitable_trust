import React from "react";
import { ImpactStatsProps } from "@/types";
import { Container } from "../ui/Container";
import { SectionHeading } from "../ui/SectionHeading";
import { StatItem } from "../ui/StatItem";
import { GraduationCap, Home, Laptop, Heart } from "lucide-react";

export const ImpactStats: React.FC<ImpactStatsProps> = ({
  title,
  subtitle,
  stats,
}) => {
  const icons = [
    <GraduationCap size={24} key="grad" />,
    <Home size={24} key="home" />,
    <Laptop size={24} key="laptop" />,
    <Heart size={24} key="heart" />,
  ];

  return (
    <section className="py-20 bg-mint/40 relative overflow-hidden">
      <Container>
        <SectionHeading
          title={title}
          subtitle={subtitle}
          badge="Our Impact"
          centered
          className="mb-12 sm:mb-16!"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {stats.map((stat, index) => (
            <StatItem
              key={index}
              value={stat.value}
              label={stat.label}
              description={stat.description}
              icon={icons[index % icons.length]}
            />
          ))}
        </div>
      </Container>
    </section>
  );
};
