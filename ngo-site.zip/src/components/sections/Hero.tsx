"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import { HeroProps } from "@/types";
import { Container } from "../ui/Container";
import { Button } from "../ui/Button";
import { BackgroundPattern } from "../ui/BackgroundPattern";
import { cn } from "@/utils/cn";

export const Hero: React.FC<HeroProps> = ({
  heading,
  subheading,
  primaryCtaText,
  primaryCtaLink,
  secondaryCtaText,
  secondaryCtaLink,
}) => {
  // Determine layout variant deterministically from props rather than pathname to prevent hydration mismatch
  const isAboutPage = !primaryCtaText;

  // Carousel images for Home Page Hero
  const homeSlides = [
    {
      id: "slide1",
      src: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=1000&auto=format&fit=crop",
      alt: "Children and educator learning outdoors with tablet",
    },
    {
      id: "slide2",
      src: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=1000&auto=format&fit=crop",
      alt: "Children reading books in a group",
    },
  ];

  const [activeSlide, setActiveSlide] = useState(0);

  useEffect(() => {
    if (isAboutPage) return;
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % homeSlides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isAboutPage, homeSlides.length]);

  if (isAboutPage) {
    // About Us Page Hero Layout
    return (
      <section className="relative overflow-hidden pt-28 pb-16 md:pt-36 md:pb-24 bg-cream border-b border-forest/5">
        {/* Leaf Background Pattern */}
        <BackgroundPattern variant="leaf" opacity={0.6} className="text-forest/10" />

        <Container className="relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
            {/* Left Content Column */}
            <div className="lg:col-span-6 flex flex-col items-start text-left max-w-xl">
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-charcoal font-heading leading-tight mb-6">
                {heading}
              </h1>
              <p className="text-base sm:text-lg text-charcoal/70 leading-relaxed font-body">
                {subheading}
              </p>
            </div>

            {/* Right Image Column */}
            <div className="lg:col-span-6 w-full relative aspect-[1.4] rounded-[32px] overflow-hidden border border-forest/10 shadow-sm">
              <Image
                src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=1000&auto=format&fit=crop"
                alt="Children reading and learning in a classroom"
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
          </div>
        </Container>
      </section>
    );
  }

  // Home Page Hero Layout
  return (
    <section className="relative pt-24 pb-16 md:pt-32 md:pb-20 bg-cream">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Content Card - Nested Outer Sage with Inner White Card */}
          <div className="lg:col-span-5 relative bg-sage border border-forest/10 rounded-[32px] p-6 flex flex-col justify-center overflow-hidden shadow-xs">
            {/* Outer Sage Card Background Leaf Pattern */}
            <BackgroundPattern variant="leaf" opacity={0.5} className="text-forest/15 animate-pulse" />
            
            {/* Inner White Card */}
            <div className="relative bg-white rounded-3xl p-8 sm:p-10 z-10 flex flex-col items-center text-center shadow-xs h-full justify-between">
              <div>
                <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-charcoal font-heading leading-tight mb-6">
                  {heading}
                </h1>
                <p className="text-sm sm:text-base text-charcoal/70 leading-relaxed font-body mb-8">
                  {subheading}
                </p>
              </div>
              <Button
                label={primaryCtaText}
                variant="primary"
                href={primaryCtaLink}
                className="bg-navy text-white hover:bg-forest hover:text-white rounded-full px-8 py-3 font-bold transition-all duration-300 shadow-sm"
              />
            </div>
          </div>

          {/* Right Carousel Column */}
          <div className="lg:col-span-7 relative w-full aspect-[4/3] lg:aspect-auto rounded-[32px] overflow-hidden border border-forest/10 shadow-sm group">
            {homeSlides.map((slide, idx) => (
              <div
                key={slide.id}
                className={cn(
                  "absolute inset-0 transition-opacity duration-700 ease-in-out",
                  activeSlide === idx ? "opacity-100 z-10" : "opacity-0 z-0"
                )}
                aria-live="polite"
              >
                <Image
                  src={slide.src}
                  alt={slide.alt}
                  fill
                  priority={idx === 0}
                  sizes="(max-width: 1024px) 100vw, 60vw"
                  className="object-cover"
                />
              </div>
            ))}

            {/* Carousel Navigation Indicator Dots */}
            <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-20 flex gap-2">
              {homeSlides.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveSlide(idx)}
                  className={cn(
                    "w-2.5 h-2.5 rounded-full transition-all duration-300",
                    activeSlide === idx ? "bg-white scale-120" : "bg-white/50 hover:bg-white/85"
                  )}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};
