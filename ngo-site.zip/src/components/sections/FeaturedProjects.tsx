import React from "react";
import { FeaturedProjectsProps } from "@/types";
import { Container } from "../ui/Container";
import { SectionHeading } from "../ui/SectionHeading";
import { ProjectCard } from "../ui/ProjectCard";
import { Button } from "../ui/Button";
import { ArrowRight } from "lucide-react";
import { PageRoutes } from "@/types";

export const FeaturedProjects: React.FC<FeaturedProjectsProps> = ({
  title,
  subtitle,
  projects,
}) => {
  // Limit to 3 projects for the featured layout
  const featured = projects.slice(0, 3);

  return (
    <section className="py-20 bg-cream border-t border-forest/10">
      <Container>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <SectionHeading
            title={title}
            subtitle={subtitle}
            badge="Our Work"
            className="mb-0! max-w-2xl"
          />
          <Button
            label="View All Projects"
            variant="outline"
            href={PageRoutes.OUR_PROJECTS}
            icon={<ArrowRight size={16} />}
            iconPosition="right"
            className="hidden md:inline-flex bg-cream"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featured.map((project) => (
            <ProjectCard key={project.slug} project={project} />
          ))}
        </div>

        <div className="mt-10 text-center md:hidden">
          <Button
            label="View All Projects"
            variant="outline"
            href={PageRoutes.OUR_PROJECTS}
            icon={<ArrowRight size={16} />}
            iconPosition="right"
            className="w-full"
          />
        </div>
      </Container>
    </section>
  );
};
